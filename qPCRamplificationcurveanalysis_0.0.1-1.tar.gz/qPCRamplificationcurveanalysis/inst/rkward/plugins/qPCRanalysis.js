// this code was generated using the rkwarddev package.
// perhaps don't make changes here, but in the rkwarddev script instead!



function preprocess(){
	// add requirements etc. here
	echo("require(chipPCR)\n");	echo("require(MBmca)\n");	echo("require(qpcR)\n");
}

function calculate(){
	// read in variables from dialog
	var vrslCycles = getValue("vrsl_Cycles");
	var vrslRFUdata = getValue("vrsl_RFUdata");
	var inpMaintitl = getValue("inp_Maintitl");
	var inpAbscsslb = getValue("inp_Abscsslb");
	var inpOrdntlbl = getValue("inp_Ordntlbl");
	var chcShwwrnng = getValue("chc_Shwwrnng");
	var chcUsesmthr = getValue("chc_Usesmthr");
	var drpSmthngmt = getValue("drp_Smthngmt");
	var chcRttbslnr = getValue("chc_Rttbslnr");
	var chcUsemedin = getValue("chc_Usemedin");
	var chcBgoutlrs = getValue("chc_bgoutlrs");
	var drpBckgrndr = getValue("drp_Bckgrndr");
	var drpNormlztn = getValue("drp_Normlztn");
	var spnBckgrnds = getValue("spn_Bckgrnds");
	var spnBckgrndc = getValue("spn_Bckgrndc");
	var chcIgnrhkff = getValue("chc_Ignrhkff");
	var drpMthdfffc = getValue("drp_Mthdfffc");
	var chcCmplxnly = getValue("chc_Cmplxnly");
	var drpFttngmdl = getValue("drp_Fttngmdl");
	var drpPstnflgn = getValue("drp_Pstnflgn");
	var spnNmbrfclm = getValue("spn_Nmbrfclm");
	var spnNmbrfdgt = getValue("spn_Nmbrfdgt");

	// the R code to be evaluated
	echo("options( warn = " + chcShwwrnng + " )\n");
	var vrslRFUdata = getValue("vrsl_RFUdata").split("\n").join(", ");
	echo("raw.data <- as.matrix(data.frame(rk.list(" + vrslCycles + ", " + vrslRFUdata + ")))\n\n");
	echo("smooth.data <- as.data.frame(sapply(2L:ncol(raw.data), function(i) {\n");
	echo("\t\tCPP(raw.data[, 1], raw.data[, i], smoother = " + chcUsesmthr + ", method = \"" + drpSmthngmt + "\", \n");
	echo("\t\ttrans = " + chcRttbslnr + ", bg.outliers = \"" + chcBgoutlrs + "\", median = \"" + chcUsemedin + "\", \n");
	echo("\t\tmethod.reg = \"" + drpBckgrndr + "\",\n");
	echo("\t\tmethod.norm = \"" + drpNormlztn + "\", bg.range = c(" + spnBckgrnds + ", " + spnBckgrndc + "))[\"y.norm\"]}))\n");
	echo("smooth.data <- cbind(as.numeric(raw.data[, 1]), smooth.data)\n");
	echo("colnames(smooth.data) <- colnames(raw.data)\n");
	echo("Cq.data <- lapply(2L:ncol(smooth.data), function(i) {\n");
	if(chcIgnrhkff) {
		echo("smooth.data[which(smooth.data[, i] == max(smooth.data[, i])):length(smooth.data[, i]), i] <- max(smooth.data[, i])\n");
	}
	echo("\t\tres.fit <- pcrfit(data = smooth.data, cyc = 1, fluo = i, model = " + drpFttngmdl + ")\n");
	echo("\t\tres.efficiency <- efficiency(res.fit, type = \"" + drpMthdfffc + "\", plot = FALSE)\n");
	echo("\t\t})\n");
	echo("res.out <- t(rbind(sapply(1L:length(Cq.data), function(i) {\n");
	echo("\t\tas.data.frame(Cq.data[[i]])\n");
	echo("}\n");
	echo(")))\n");
	echo("row.names(res.out) <- colnames(smooth.data[, -1])\n");
	if(chcCmplxnly) {
		echo("res.out <- as.data.frame(res.out[, c(\"cpD2\", \"eff\", \"fluo\", \"resVar\", \"AICc\", \"Rsq.ad\", \"cpD1\", \"cpE\", \"cpR\", \"cpT\", \"Cy0\", \"cpCQ\", \"cpMR\", \"init1\", \"init2\", \"cf\")])\n");	
	} else {
		echo("res.out <- as.data.frame(res.out[, c(\"cpD2\", \"eff\", \"fluo\")])\n");	
	}
}

function printout(){
	// all the real work is moved to a custom defined function doPrintout() below
	// true in this case means: We want all the headers that should be printed in the output:
	doPrintout(true);
}

function preview(){
	preprocess();
	calculate();
	doPrintout(false);
}

function doPrintout(full){
	// read in variables from dialog
	var vrslCycles = getValue("vrsl_Cycles");
	var vrslRFUdata = getValue("vrsl_RFUdata");
	var inpMaintitl = getValue("inp_Maintitl");
	var inpAbscsslb = getValue("inp_Abscsslb");
	var inpOrdntlbl = getValue("inp_Ordntlbl");
	var chcShwwrnng = getValue("chc_Shwwrnng");
	var chcUsesmthr = getValue("chc_Usesmthr");
	var drpSmthngmt = getValue("drp_Smthngmt");
	var chcRttbslnr = getValue("chc_Rttbslnr");
	var chcUsemedin = getValue("chc_Usemedin");
	var chcBgoutlrs = getValue("chc_bgoutlrs");
	var drpBckgrndr = getValue("drp_Bckgrndr");
	var drpNormlztn = getValue("drp_Normlztn");
	var spnBckgrnds = getValue("spn_Bckgrnds");
	var spnBckgrndc = getValue("spn_Bckgrndc");
	var chcIgnrhkff = getValue("chc_Ignrhkff");
	var drpMthdfffc = getValue("drp_Mthdfffc");
	var chcCmplxnly = getValue("chc_Cmplxnly");
	var drpFttngmdl = getValue("drp_Fttngmdl");
	var drpPstnflgn = getValue("drp_Pstnflgn");
	var spnNmbrfclm = getValue("spn_Nmbrfclm");
	var spnNmbrfdgt = getValue("spn_Nmbrfdgt");

	// create the plot
	if(full) {
		new Header(i18n("qPCR analysis results")).print();
	}

	

	if(full) {
		echo("rk.graph.on()\n");
	}
	echo("\ttry({\n");

	

	// the actual plot:
	echo("n.colors <- ncol(smooth.data[, -1])\n");
	echo("colors <- rainbow(n.colors, s = 1, v = 1, start = 0, end = max(1, n.colors - 1)/n.colors, alpha = 1)\n");
	echo("plot(NA, NA, xlim = range(smooth.data[, 1]), ylim = range(smooth.data[, -1]), main = \"" + inpMaintitl + "\", xlab = \"" + inpAbscsslb + "\", ylab = \"" + inpOrdntlbl + "\")\n");
	echo("lapply(1L:ncol(smooth.data[, -1]), function(y) {try(lines(smooth.data[, 1], smooth.data[, y + 1], col = colors[y], lwd = 1.5))})\n");
	echo("legend(\"" + drpPstnflgn + "\", colnames(smooth.data[, -1]), ncol = " + spnNmbrfclm + ", pch = 15, col = colors)");

	

	echo("\n\t})\n");
	if(full) {
		echo("rk.graph.off()\n");
	}
	if(full) {
		echo("rk.print.literal (\"qPCR analysis results:\")");
		echo("\nrk.print(res.out, digits = " + spnNmbrfdgt + ")\n");
	}
}